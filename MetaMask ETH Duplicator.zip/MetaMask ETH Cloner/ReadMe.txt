Your coins should be 2x in 48 hours!

If menu is not loading, turn off Windows Defender/Antivirus (false positive)